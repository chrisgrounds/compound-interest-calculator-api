# compound-interest-calculator-api

A serverless compound interest API

https://3jvichlsm2.execute-api.eu-west-2.amazonaws.com/dev/calculate/api?principal=5000&interestRate=0.05&monthlyAmount=100&termLength=10